Final Networking
I wanted to submit this too. I found a good tutorial online and walked through it trying to understand how it works. But this isn't finding my MAC addy. Not sure why but I tried my best.


